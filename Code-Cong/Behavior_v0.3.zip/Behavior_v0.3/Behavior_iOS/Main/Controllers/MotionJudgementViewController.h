//
//  MotionJudgementViewController.h
//  20-3-MotionMonitor
//
//  Created by Cong on 2017/3/30.
//  Copyright © 2017年 Cong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MotionJudgementViewController : UIViewController

@end
