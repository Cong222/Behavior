//
//  ViewController.h
//  20-3-MotionMonitor
//
//  Created by Cong on 2017/3/15.
//  Copyright © 2017年 Cong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MotionInformationViewController : UIViewController


@end

